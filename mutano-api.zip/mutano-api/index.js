/**
 * API MutanoX - Entry Point
 * Autor: @MutanoX
 */

require('./api.js');
